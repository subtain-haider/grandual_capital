appML
=====

application markup language
an easy way to build webApp by using html5 tags
